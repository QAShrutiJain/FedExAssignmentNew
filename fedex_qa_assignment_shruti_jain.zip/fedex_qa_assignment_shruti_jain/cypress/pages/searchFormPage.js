class SearchFormPage {

  // Define the selectors for the search input and result elements
  searchInput = () => cy.get('[data-test-id="search-input"]');
  searchButton = () => cy.get('[data-test-id="search-button"]')
  searchResultsNotFound = () => cy.contains('Not found')

  searchFor = (query) => {
    this.searchInput().type(query)
    return this;
  }
  //Method to click on search 
  search = () => {
    this.searchButton().click();
    return this;
  }
  searchByEnter = () => {
    this.searchButton().type('{enter}');
    return this;
  }
  clearSearchInput = () => {
    this.searchInput().clear()
    return this;
  }
  // Define a method to assert the search results for people
  assertNotFound = () => {
    //  this.searchResults().contains('Not found')
    this.searchResultsNotFound()
  }
}
export default new SearchFormPage;
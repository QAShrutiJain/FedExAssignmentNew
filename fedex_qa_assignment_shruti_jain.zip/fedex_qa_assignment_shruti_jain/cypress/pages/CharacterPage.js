class CharacterPage {
  
  characterSelectorButton = () => cy.get('[data-test-id="people-button"]');
  characterCard = () => cy.get('[data-test-id="character-card"]');
 
  //Method to click on people search radio button
  characterSearch = () => {
    this.characterSelectorButton().click()
    return this;
  }
  //Validate the character info for full character search or partial character text search
  validateCharacterInfo = (testData, isCharacter) => {
      this.characterCard().each(function($el,index,$listofelements){
        const text = $el.text()
        const gender = text.match(/Gender: (\w+)/)[1]
        const birthYear = text.match(/Birth year: (\w+)/)[1]
        const eyeColor = text.match(/Eye color: (\w+)/)[1]
        const skinColor = text.match(/Skin color: (\w+)/)[1]
        if (isCharacter){
              expect(gender).to.equal(testData.Character.gender) 
              expect(birthYear).to.equal(testData.Character.birthYear) 
              expect(eyeColor).to.equal(testData.Character.eyeColor) 
              expect(skinColor).to.equal(testData.Character.skinColor) 
        }else if (!isCharacter) {
              assert.exists(gender)
              assert.exists(birthYear)
              assert.exists(eyeColor)
              assert.exists(skinColor)
        }    
      })
      return this; 
    }    
}
export default new CharacterPage;
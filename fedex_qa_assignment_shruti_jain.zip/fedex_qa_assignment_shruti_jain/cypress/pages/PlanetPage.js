class PlanetPage {

  // Define the selectors for the search input and result elements
  planetSelectorButton = () => cy.get('[data-test-id="planet-button"]')
  planetCard = () => cy.get('[data-test-id="planet-card"]')

  //Method to click on planet search radio button
  planetSearch = () => {
    this.planetSelectorButton().click();
    return this;
  }

  //Validate the character info for full character search or partial character text search
  validatePlanetInfo = (testData, isPlanet) => {
    this.planetCard().each(function ($el, index, $listofelements) {
      const text = $el.text();
      const population = text.match(/Population: (\w+)/)[1];
      const climate = text.match(/Climate: (\w+)/)[1];
      const gravity = text.match(/Gravity: \s*(.*?)\s*$/)[1];
      if (isPlanet) {
        expect(population).to.equal(testData.Planet.population)
        expect(climate).to.equal(testData.Planet.climate)
        expect(gravity).to.equal(testData.Planet.gravity)
      } else if (!isPlanet) {
        assert.exists(population)
        assert.exists(climate)
        assert.exists(gravity)
      }
    })
    return this;
  }

}
export default new PlanetPage;
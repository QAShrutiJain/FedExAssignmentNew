import planetpage from '../../pages/PlanetPage';
import searchformpage from '../../pages/searchFormPage';

describe('Search Planet functionality', () => {

  let testData;
    before('Load test data', () => {
      cy.fixture('testDataCharactersAndPlanets').then((testDataFromFixture) => {
        testData = testDataFromFixture;
      })
    })

    // Define the beforeEach hook to navigate to the search page before each test
    beforeEach(() => {
      cy.visit('/');
    });
  
    // Full matchinf Text search for planet
    it('should display Population, Climate, and Gravity for valid planet search', () => {
      //click radio button
      const isPlanet = true
      planetpage
        .planetSearch()
      searchformpage  
        .searchFor(testData.Planet.name)
        .search()
      planetpage  
        .validatePlanetInfo(testData, isPlanet)
        //Todo to matach all the information from test data
    })
    
    
    // Partial Text search for planet
    it('should display Population, Climate, and Gravity for valid planet search', () => {
      //click radio button
      const isPlanet = false
      planetpage
        .planetSearch()
      searchformpage  
        .searchFor(testData.partialText)
        .search()
      planetpage  
        .validatePlanetInfo(testData, isPlanet )
    })
  
    // Define the test for searching for people with an invalid query
    it('should display "Not found" for invalid planet search', () => {
      //click radio button
      planetpage
        .planetSearch()
      searchformpage  
        .searchFor('invalid query')
        .search()
        .assertNotFound()
    });

    // Validate planet by presssing enter
    it('search should work by clicking or pressing enter', () => {
      planetpage
        .planetSearch()
      searchformpage  
        .searchFor(testData.invalidText)
        //press enter to search
        .searchByEnter()
        .assertNotFound()
    });
});


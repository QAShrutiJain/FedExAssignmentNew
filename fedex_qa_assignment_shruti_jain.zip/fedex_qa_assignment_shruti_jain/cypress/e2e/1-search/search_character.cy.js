import characterPage from '../../pages/CharacterPage';
import planetpage from '../../pages/PlanetPage';
import searchformpage from '../../pages/searchFormPage';


describe('Search Character functionality', () => {
  // Define the beforeEach hook to navigate to the search page before each test
  let testData;
  before('Load test data', () => {
    cy.fixture('testDataCharactersAndPlanets').then((testDataFromFixture) => {
      testData = testDataFromFixture;
    })
  })

  beforeEach(() => {
    cy.visit('/'); 
  });



  //Verify the exact search scenarios. In this block I am entering the complete name of the character. I have test data of that character in the fixture json file. 
  //In this block I am asserting if the search results for particular character the Gender, Birth Year, EyeColor and Skin color is matching with the test Data. 
  it('should match Birth year, Eye color, and Skin color for valid character search', () => {
    const isCharacter = true
    characterPage
      .characterSearch()
    searchformpage
      .searchFor(testData.Character.name)
      .search()
    characterPage
      .validateCharacterInfo(testData, isCharacter)
  });

  //Verify the partial search scenarios. In this block we are entering a partial character which will display more than one character information.
  //I am asserting if for each character displayed his/her Gender, BirthYear, EyeColor and Skin color is displayed. This block will fail if for any of the character the infomation is missing(spaces).
  it('should display Birth year, Eye color, and Skin color for partial character search', () => {
    const isCharacter = false
    characterPage
      .characterSearch()
    searchformpage
      .searchFor(testData.partialText)
      .search()
    characterPage
      .validateCharacterInfo(testData, isCharacter)
  });



  // Validate the test for searching for character with an invalid character
  it('should display "Not found" for invalid people search', () => {
    characterPage
      .characterSearch()
    searchformpage
      .searchFor(testData.invalidText)
      .search()
      .assertNotFound()
  });

  //Validate clear search form
  it('should display "Not found" after clearning search form', () => {
    characterPage
      .characterSearch()
    searchformpage
      .searchFor(testData.partialText)
      .search()
      .clearSearchInput()
      .search()
      .assertNotFound()
  });

  // Validate character by presssing enter
  it('search should work by clicking or pressing enter', () => {
    characterPage
      .characterSearch()
    searchformpage
      .searchFor(testData.invalidText)
      //press enter to search
      .searchByEnter()
      .assertNotFound()
  });

  // Validate switching character/planet and search for the same thing result in 'not found'
  it('Validate switching character/planet search', () => {
    characterPage
      .characterSearch()
    searchformpage
      .searchFor(testData.Character.name)
      //press enter to search
      .search()
    //swtich to planet  
    planetpage
      .planetSearch()
    searchformpage
      .search()
      .assertNotFound()
  });


});
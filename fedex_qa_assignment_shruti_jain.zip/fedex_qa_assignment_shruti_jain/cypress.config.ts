import { defineConfig } from "cypress";

export default defineConfig({

  e2e: {

  screenshotOnRunFailure: true,
  video: true,
  experimentalWebKitSupport: true,
  scrollBehavior: 'center',

    setupNodeEvents(on, config) {
      // implement node event listeners here
    },

    baseUrl: 'http://localhost:4200/',
    specPattern: 'cypress/e2e/**/*.cy.js',
    defaultCommandTimeout: 10000,
    chromeWebSecurity: false,
    
    reporter: "mochawesome",
    reporterOptions: {
        reportDir: "cypress/report/mochawesome-report",
        overwrite: true,
        charts: true,
        html: true,
        json: false,
        timestamp: "mmddyyyy_HHMMss"
      }

  },
});
